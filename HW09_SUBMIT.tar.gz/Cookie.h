#ifndef COOKIE_BITMAP_H
#define COOKIE_BITMAP_H
extern const unsigned short Cookie[100];
#define COOKIE_WIDTH 10
#define COOKIE_HEIGHT 10
#endif