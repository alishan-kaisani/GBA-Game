#ifndef FIRE_BITMAP_H
#define FIRE_BITMAP_H
extern const unsigned short Fire[100];
#define FIRE_WIDTH 10
#define FIRE_HEIGHT 10
#endif