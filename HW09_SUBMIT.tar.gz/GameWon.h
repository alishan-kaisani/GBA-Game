#ifndef GAMEWON_BITMAP_H
#define GAMEWON_BITMAP_H
extern const unsigned short GameWon[38400];
#define GAMEWON_WIDTH 240
#define GAMEWON_HEIGHT 160
#endif